package com.cg.account.WalletAccountSpring.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Transaction implements Serializable {
	private static final long serialVersionUID = 1L;

	String mobile;

	String transaction;
	@Id
	String time;

	public String getMobnum() {
		return mobile;
	}

	public void setMobnum(String mobnum) {
		this.mobile = mobnum;
	}

	public String getTransaction() {
		return transaction;
	}

	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String localDateTime) {
		this.time = localDateTime;
	}
}
