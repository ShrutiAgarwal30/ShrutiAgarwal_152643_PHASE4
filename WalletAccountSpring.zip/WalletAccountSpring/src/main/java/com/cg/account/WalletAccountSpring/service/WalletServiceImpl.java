package com.cg.account.WalletAccountSpring.service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.cg.account.WalletAccountSpring.entities.Customer;
import com.cg.account.WalletAccountSpring.entities.Transaction;
import com.cg.account.WalletAccountSpring.repo.TransactionRepo;
import com.cg.account.WalletAccountSpring.repo.WalletRepo;


@Service
public class WalletServiceImpl implements WalletService {
	@PersistenceContext
	private EntityManager entityManager;
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

	@Autowired
	WalletRepo repo;
	@Autowired
	TransactionRepo treop;
	

	@Override
	public void addAccount(Customer customer) {
		repo.save(customer);

	}

	@Override
	public Optional<Customer> showBalance(String mobnum) {

		return repo.findById(mobnum);
	}

	@Override
	public Customer transferFund(String mobile, String rmobile, BigDecimal balance) {
		Optional<Customer> customerinfo = repo.findById(mobile);
		Optional<Customer> customerinfo1 = repo.findById(rmobile);
		BigDecimal amount1 = customerinfo.get().getWalletBalance();
		BigDecimal amount2 = customerinfo1.get().getWalletBalance();
		amount1 = amount1.subtract(balance);
		customerinfo.get().setWalletBalance(amount1);
		Customer cust = repo.save(customerinfo.get());
		BigDecimal finalamount = amount2.add(balance);
		customerinfo1.get().setWalletBalance(finalamount);
		repo.save(customerinfo1.get());
		Transaction transaction=new Transaction();
		transaction.setMobnum(mobile);
		LocalDateTime localdateTime = LocalDateTime.now();
		transaction.setTime(localdateTime.format(formatter));
		transaction.setTransaction("FundTransfered" + balance + " to- " + rmobile);
		treop.save(transaction);
		return cust;

	}

	@Override
	public Customer depositBalance(String mobile, BigDecimal balance) {
		Optional<Customer> customerinfo = repo.findById(mobile);
		BigDecimal amountnew = customerinfo.get().getWalletBalance().add(balance);

		customerinfo.get().setWalletBalance(amountnew);

		Customer cust = repo.save(customerinfo.get());
		Transaction transaction=new Transaction();
		transaction.setMobnum(mobile);
		LocalDateTime localdateTime = LocalDateTime.now();
		transaction.setTime(localdateTime.format(formatter));
		transaction.setTransaction("Amount Deposited : " + balance + " to- " + mobile);
		treop.save(transaction);
		return cust;
	}

	@Override
	public Customer withdrawal(String mobile, BigDecimal balance) {

		Optional<Customer> customerinfo = repo.findById(mobile);
		BigDecimal amountnew = customerinfo.get().getWalletBalance().subtract(balance);

		customerinfo.get().setWalletBalance(amountnew);

		Customer cust = repo.save(customerinfo.get());
		Transaction transaction=new Transaction();
		transaction.setMobnum(mobile);
		LocalDateTime localdateTime = LocalDateTime.now();
		transaction.setTime(localdateTime.format(formatter));
		transaction.setTransaction("Amount WithDrawn : " + balance + " to- " + mobile);
		treop.save(transaction);

		return cust;
	}

	@Override
	public List<Transaction> printTransactions(String mobile) {
		Query query = entityManager.createQuery("FROM Transaction where mobile=?");
		query.setParameter(0, mobile);
		@SuppressWarnings("unchecked")
		List<Transaction> selectedTransactions = query.getResultList();
		return selectedTransactions;
	}
	

}
